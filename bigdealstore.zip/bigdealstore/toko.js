import { db } from "./firebase-config.js";
import { collection, getDocs, query, orderBy } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

let semuaProduk = [];
let daftar = document.getElementById("daftarProduk");
let filterAktif = "Semua";
let subFilterAktif = null;
let subFilterMode = "kategori";

// ============ DETEKSI BRAND DARI NAMA PRODUK ============
function deteksiBrand(namaProduk) {
    if (!namaProduk) return null;
    const nome = namaProduk.toLowerCase();
    
    const brandList = [
        { keyword: "samsung", brand: "Samsung" },
        { keyword: "iphone", brand: "Apple" },
        { keyword: "apple", brand: "Apple" },
        { keyword: "macbook", brand: "Apple" },
        { keyword: "ipad", brand: "Apple" },
        { keyword: "xiaomi", brand: "Xiaomi" },
        { keyword: "redmi", brand: "Xiaomi" },
        { keyword: "poco", brand: "Xiaomi" },
        { keyword: "oppo", brand: "OPPO" },
        { keyword: "vivo", brand: "VIVO" },
        { keyword: "realme", brand: "Realme" },
        { keyword: "infinix", brand: "Infinix" },
        { keyword: "tecno", brand: "Tecno" },
        { keyword: "techno", brand: "Tecno" },
        { keyword: "asus", brand: "ASUS" },
        { keyword: "lenovo", brand: "Lenovo" },
        { keyword: "dell", brand: "Dell" },
        { keyword: "acer", brand: "Acer" },
        { keyword: "msi", brand: "MSI" },
        { keyword: "sony", brand: "Sony" },
        { keyword: "lg", brand: "LG" },
    ];

    for (let item of brandList) {
        if (nome.includes(item.keyword)) {
            return item.brand;
        }
    }
    return null;
}

// ============ DAPATKAN SEMUA BRAND UNIK ============
function getBrandList(produk) {
    let brandSet = new Set();
    produk.forEach(p => {
        let brand = deteksiBrand(p.nama);
        if (brand) {
            brandSet.add(brand);
        }
    });
    return Array.from(brandSet).sort();
}

// ============ TAMPIL PRODUK ============
async function tampilProduk() {
    try {
        let q = query(collection(db, "produk"), orderBy("tanggal", "desc"));
        let data = await getDocs(q);
        semuaProduk = [];

        data.forEach((doc) => {
            let p = doc.data();
            p.id = doc.id;
            if (p.status === "READY" || !p.status) {
                semuaProduk.push(p);
            }
        });

        updateSubFilter(semuaProduk);
        filterProduk(filterAktif, subFilterAktif);
    } catch (error) {
        console.error(error);
        daftar.innerHTML = "<p style='color:red; text-align:center;'>❌ Gagal memuat produk. Coba refresh.</p>";
    }
}

// ============ UPDATE SUB-FILTER ============
function updateSubFilter(produk) {
    let subFilterGrid = document.getElementById("subFilterGrid");
    if (!subFilterGrid) return;

    let kategoriSet = new Set();
    produk.forEach(p => {
        if (p.kategori && p.kategori.trim()) {
            kategoriSet.add(p.kategori.trim());
        }
    });
    let kategoriList = Array.from(kategoriSet).sort();
    let brandList = getBrandList(produk);

    let html = '';
    html += `<div style="width:100%; margin-bottom:8px; display:flex; flex-wrap:wrap; align-items:center; gap:10px;">`;
    html += `<span style="color:#666; font-size:11px; text-transform:uppercase; letter-spacing:1px;">Kategori:</span>`;
    html += `<button class="sub-filter-btn active" data-mode="kategori" data-sub="Semua">Semua</button>`;
    kategoriList.forEach(kat => {
        html += `<button class="sub-filter-btn" data-mode="kategori" data-sub="${kat}">${kat}</button>`;
    });

    if (brandList.length > 0) {
        html += `<span style="color:#333; margin:0 5px;">|</span>`;
        html += `<span style="color:#666; font-size:11px; text-transform:uppercase; letter-spacing:1px;">Brand:</span>`;
        brandList.forEach(brand => {
            html += `<button class="sub-filter-btn" data-mode="brand" data-sub="${brand}">${brand}</button>`;
        });
    }

    html += `</div>`;
    subFilterGrid.innerHTML = html;

    document.querySelectorAll('.sub-filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.sub-filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            let mode = this.dataset.mode;
            let sub = this.dataset.sub;
            
            if (sub === "Semua") {
                subFilterAktif = null;
                subFilterMode = mode;
            } else {
                subFilterAktif = sub;
                subFilterMode = mode;
            }
            
            filterProduk(filterAktif, subFilterAktif, subFilterMode);
        });
    });
}

// ============ FILTER PRODUK ============
function filterProduk(kategori, subKategori = null, mode = "kategori") {
    filterAktif = kategori;

    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.filter === kategori);
    });

    let hasil = semuaProduk;

    if (kategori !== "Semua") {
        hasil = hasil.filter(p => p.kategori === kategori);
    }

    if (subKategori) {
        if (mode === "kategori") {
            hasil = hasil.filter(p => p.kategori === subKategori);
        } else if (mode === "brand") {
            hasil = hasil.filter(p => {
                let brand = deteksiBrand(p.nama);
                return brand === subKategori;
            });
        }
    }

    tampilkanData(hasil);
}

// ============ TAMPILKAN DATA ============
function tampilkanData(data) {
    daftar.innerHTML = "";
    document.getElementById("jumlahProduk").textContent = data.length + " produk";

    if (data.length === 0) {
        daftar.innerHTML = "<p style='text-align:center; color:#999; grid-column:1/-1;'>📭 Belum ada produk tersedia</p>";
        return;
    }

    data.forEach((p) => {
        let fotoUtama = (p.foto && p.foto.length > 0) ? p.foto[0] : "https://via.placeholder.com/300x200/1a1a1a/2563eb?text=BigDealStore";
        let galeri = "";

        if (p.foto && p.foto.length > 0) {
            p.foto.forEach((foto) => {
                galeri += `<img src="${foto}" onclick="event.stopPropagation(); gantiFoto(this)" alt="Thumbnail">`;
            });
        }

        let badgeHtml = "";
        if (p.badge === "New") badgeHtml = `<span class="badge-produk new">New</span>`;
        else if (p.badge === "Best Seller") badgeHtml = `<span class="badge-produk best">Best Seller</span>`;
        else if (p.badge === "Diskon") badgeHtml = `<span class="badge-produk diskon">Diskon</span>`;
        else if (p.badge === "Promo") badgeHtml = `<span class="badge-produk promo">Promo</span>`;

        let brand = deteksiBrand(p.nama);
        let brandTag = brand ? `<span class="subkategori-tag">${brand}</span>` : "";

        let hargaHtml = `<span class="harga">Rp ${Number(p.harga || 0).toLocaleString("id-ID")}</span>`;
        if (p.hargaCoret && p.hargaCoret > p.harga) {
            let diskon = Math.round(((p.hargaCoret - p.harga) / p.hargaCoret) * 100);
            hargaHtml = `
                <span class="harga">Rp ${Number(p.harga || 0).toLocaleString("id-ID")}</span>
                <span class="harga-coret">Rp ${Number(p.hargaCoret || 0).toLocaleString("id-ID")}</span>
                <span class="diskon-label">-${diskon}%</span>
            `;
        }

        let kategoriTag = p.kategori ? `<span class="kategori-tag">${p.kategori}</span>` : "";

        daftar.innerHTML += `
            <div class="card" onclick="bukaDetail('${p.id}')">
                ${badgeHtml}
                <img class="fotoUtama" src="${fotoUtama}" onclick="event.stopPropagation(); bukaFoto(this.src)" alt="${p.nama}" loading="lazy">
                <div class="thumbnail">${galeri}</div>
                ${kategoriTag} ${brandTag}
                <h3>${p.nama || "-"}</h3>
                <div class="kondisi">${p.kondisi || "-"} • Battery ${p.battery || "-"}</div>
                <div class="harga-wrap">${hargaHtml}</div>
                <p style="color:#666; font-size:13px; margin-bottom:12px;">${p.deskripsi ? p.deskripsi.substring(0,60) + "..." : ""}</p>
                <button onclick="event.stopPropagation(); window.open('https://wa.me/6281385476788?text=Halo%20BigDealStore%20saya%20tertarik%20dengan%20${encodeURIComponent(p.nama)}','_blank')">
                    Beli Sekarang
                </button>
            </div>
        `;
    });
}

// ============ EVENT LISTENER FILTER UTAMA ============
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            subFilterAktif = null;
            subFilterMode = "kategori";
            document.querySelectorAll('.sub-filter-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.sub-filter-btn').forEach(b => {
                if (b.dataset.sub === "Semua" && b.dataset.mode === "kategori") {
                    b.classList.add('active');
                }
            });
            filterProduk(this.dataset.filter);
        });
    });
});

// ============ FUNGSI FOTO ============
window.gantiFoto = function(gambar) {
    let card = gambar.closest(".card");
    if (card) {
        card.querySelector(".fotoUtama").src = gambar.src;
    }
};

window.bukaFoto = function(url) {
    let popup = document.createElement("div");
    popup.style.cssText = `
        position:fixed; top:0; left:0; width:100%; height:100%;
        background:rgba(0,0,0,0.9); display:flex; align-items:center;
        justify-content:center; z-index:9999; cursor:pointer;
    `;
    popup.innerHTML = `<img src="${url}" style="max-width:95%; max-height:95%; object-fit:contain; border-radius:15px;">`;
    popup.onclick = function() { popup.remove(); };
    document.body.appendChild(popup);
};

window.bukaDetail = function(id) {
    if (id) {
        window.location.href = "detail.html?id=" + encodeURIComponent(id);
    }
};

// ============ JALANKAN ============
tampilProduk();