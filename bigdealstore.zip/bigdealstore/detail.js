import { db } from "./firebase-config.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

let container = document.getElementById("detailContainer");
let params = new URLSearchParams(window.location.search);
let idProduk = params.get("id");

let daftarFoto = [];
let posisiFoto = 0;

// ============ TAMPIL DETAIL ============
async function tampilDetail() {
    try {
        if (!idProduk) {
            container.innerHTML = `<div class="loading-detail" style="color:red;">❌ Produk tidak ditemukan</div>`;
            return;
        }

        let produkRef = doc(db, "produk", idProduk);
        let hasil = await getDoc(produkRef);

        if (!hasil.exists()) {
            container.innerHTML = `<div class="loading-detail" style="color:red;">❌ Data produk tidak ditemukan</div>`;
            return;
        }

        let p = hasil.data();
        daftarFoto = p.foto || [];
        let fotoUtama = (daftarFoto.length > 0) ? daftarFoto[0] : "https://via.placeholder.com/600x450/1a1a1a/2563eb?text=BigDealStore";

        let badgeHtml = "";
        if (p.badge === "New") badgeHtml = `<span class="badge-produk new">New</span>`;
        else if (p.badge === "Best Seller") badgeHtml = `<span class="badge-produk best">Best Seller</span>`;
        else if (p.badge === "Diskon") badgeHtml = `<span class="badge-produk diskon">Diskon</span>`;
        else if (p.badge === "Promo") badgeHtml = `<span class="badge-produk promo">Promo</span>`;

        let kategoriTag = p.kategori ? `<span class="kategori-tag">${p.kategori}</span>` : "";
        let subKategoriTag = p.subKategori ? `<span class="subkategori-tag">${p.subKategori}</span>` : "";

        let hargaHtml = `<span class="harga">Rp ${Number(p.harga || 0).toLocaleString("id-ID")}</span>`;
        if (p.hargaCoret && p.hargaCoret > p.harga) {
            let diskon = Math.round(((p.hargaCoret - p.harga) / p.hargaCoret) * 100);
            hargaHtml = `
                <span class="harga">Rp ${Number(p.harga || 0).toLocaleString("id-ID")}</span>
                <span class="harga-coret">Rp ${Number(p.hargaCoret || 0).toLocaleString("id-ID")}</span>
                <span class="diskon-label">-${diskon}%</span>
            `;
        }

        let thumbnailHtml = "";
        if (daftarFoto.length > 0) {
            daftarFoto.forEach((foto, index) => {
                thumbnailHtml += `
                    <img src="${foto}" onclick="gantiFoto(${index})" class="${index === 0 ? 'active' : ''}" alt="Thumbnail ${index + 1}">
                `;
            });
        }

        let navButtons = "";
        if (daftarFoto.length > 1) {
            navButtons = `
                <button class="nav-btn prev" onclick="fotoSebelumnya()">‹</button>
                <button class="nav-btn next" onclick="fotoBerikutnya()">›</button>
            `;
        }

        let statusText = p.status === "READY" ? "🟢 Tersedia" : "🔴 Terjual";

        container.innerHTML = `
            <div class="galeri">
                <div class="foto-utama-wrap">
                    <img id="fotoUtama" src="${fotoUtama}" onclick="bukaFoto(this.src)" alt="${p.nama}">
                    ${navButtons}
                </div>
                <div class="indikator" id="indikatorFoto">
                    ${daftarFoto.length > 0 ? `1 / ${daftarFoto.length}` : 'Tidak ada foto'}
                </div>
                ${thumbnailHtml ? `<div class="thumbnail-wrap">${thumbnailHtml}</div>` : ''}
            </div>

            <div class="info">
                <div>
                    ${badgeHtml}
                    ${kategoriTag} ${subKategoriTag}
                </div>
                <h1>${p.nama || "-"}</h1>
                <div class="meta">
                    <span>📋 Kondisi: ${p.kondisi || "-"}</span>
                    <span>🔋 Battery: ${p.battery || "-"}</span>
                    <span>${statusText}</span>
                </div>
                <div class="harga-wrap">
                    ${hargaHtml}
                </div>
                <div class="deskripsi">
                    ${p.deskripsi || "Tidak ada deskripsi untuk produk ini."}
                </div>
                <div class="btn-group">
                    <a href="https://wa.me/6281385476788?text=Halo%20BigDealStore%20saya%20tertarik%20dengan%20${encodeURIComponent(p.nama)}%20-%20${encodeURIComponent(p.kategori || '')}%20Rp%20${Number(p.harga || 0).toLocaleString('id-ID')}" 
                       target="_blank" 
                       class="btn-primary">
                        Beli Sekarang via WhatsApp
                    </a>
                    <a href="index.html" class="btn-secondary">⬅ Kembali</a>
                </div>
            </div>
        `;

    } catch (error) {
        container.innerHTML = `<div class="loading-detail" style="color:red;">❌ Error: ${error.message}</div>`;
        console.error(error);
    }
}

// ============ FUNGSI NAVIGASI FOTO ============
window.gantiFoto = function(index) {
    if (index < 0 || index >= daftarFoto.length) return;
    posisiFoto = index;
    document.getElementById("fotoUtama").src = daftarFoto[index];
    document.getElementById("indikatorFoto").innerHTML = `${index + 1} / ${daftarFoto.length}`;
    
    document.querySelectorAll('.thumbnail-wrap img').forEach((img, i) => {
        img.classList.toggle('active', i === index);
    });
};

window.fotoSebelumnya = function() {
    if (daftarFoto.length === 0) return;
    posisiFoto = (posisiFoto - 1 + daftarFoto.length) % daftarFoto.length;
    document.getElementById("fotoUtama").src = daftarFoto[posisiFoto];
    document.getElementById("indikatorFoto").innerHTML = `${posisiFoto + 1} / ${daftarFoto.length}`;
    document.querySelectorAll('.thumbnail-wrap img').forEach((img, i) => {
        img.classList.toggle('active', i === posisiFoto);
    });
};

window.fotoBerikutnya = function() {
    if (daftarFoto.length === 0) return;
    posisiFoto = (posisiFoto + 1) % daftarFoto.length;
    document.getElementById("fotoUtama").src = daftarFoto[posisiFoto];
    document.getElementById("indikatorFoto").innerHTML = `${posisiFoto + 1} / ${daftarFoto.length}`;
    document.querySelectorAll('.thumbnail-wrap img').forEach((img, i) => {
        img.classList.toggle('active', i === posisiFoto);
    });
};

window.bukaFoto = function(url) {
    let popup = document.createElement("div");
    popup.style.cssText = `
        position:fixed; top:0; left:0; width:100%; height:100%;
        background:rgba(0,0,0,0.92); display:flex; align-items:center;
        justify-content:center; z-index:9999; cursor:pointer;
        padding:20px;
    `;
    popup.innerHTML = `<img src="${url}" style="max-width:95%; max-height:95%; object-fit:contain; border-radius:12px;">`;
    popup.onclick = function() { popup.remove(); };
    document.body.appendChild(popup);
};

// ============ KEYBOARD NAVIGATION ============
document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft') { fotoSebelumnya(); }
    if (e.key === 'ArrowRight') { fotoBerikutnya(); }
    if (e.key === 'Escape') {
        let popup = document.querySelector('div[style*="position:fixed; background:rgba(0,0,0,0.92)"]');
        if (popup) popup.remove();
    }
});

// ============ JALANKAN ============
tampilDetail();