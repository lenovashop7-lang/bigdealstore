import { db } from "./firebase-config.js";
import {
    collection, addDoc, getDocs, deleteDoc, doc, updateDoc, query, orderBy
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

let idEdit = null;
let sedangProses = false;

// ============ LOGIN ============
window.login = function() {
    let user = document.getElementById("user").value.trim();
    let pass = document.getElementById("pass").value.trim();

    if (user === "admin" && pass === "admin123") {
        document.getElementById("dashboard").style.display = "block";
        document.getElementById("loginForm").style.display = "none";
        document.getElementById("pesan").innerHTML = "";
        tampilProdukAdmin();
    } else {
        document.getElementById("pesan").innerHTML = "❌ Username atau password salah!";
    }
};

// ============ TAMBAH / UPDATE PRODUK ============
window.tambahProduk = async function() {
    if (sedangProses) return;

    try {
        let nama = document.getElementById("namaProduk").value.trim();
        let kategori = document.getElementById("kategoriProduk").value;
        let badge = document.getElementById("badgeProduk").value;
        let kondisi = document.getElementById("kondisiProduk").value.trim();
        let battery = document.getElementById("batteryProduk").value.trim();
        let harga = document.getElementById("hargaProduk").value.trim();
        let hargaCoret = document.getElementById("hargaCoretProduk").value.trim();
        let subKategori = document.getElementById("subKategoriProduk").value.trim();
        let deskripsi = document.getElementById("deskripsiProduk").value.trim();

        if (!nama || !harga) {
            alert("⚠️ Nama dan Harga wajib diisi!");
            return;
        }

        let semuaFoto = document.querySelectorAll(".fotoProduk");
        let fileFoto = [];
        semuaFoto.forEach(input => {
            if (input.files.length > 0) fileFoto.push(input.files[0]);
        });

        let urlFoto = [];
        if (idEdit && fileFoto.length === 0) {
            let q = query(collection(db, "produk"));
            let data = await getDocs(q);
            data.forEach(item => {
                if (item.id === idEdit) {
                    let p = item.data();
                    if (p.foto) urlFoto = p.foto;
                }
            });
        } else if (fileFoto.length > 0) {
            let tombol = document.getElementById("tombolSimpan");
            tombol.disabled = true;
            tombol.innerHTML = "⏳ Uploading...";
            sedangProses = true;

            for (let i = 0; i < fileFoto.length; i++) {
                let formData = new FormData();
                formData.append("file", fileFoto[i]);
                formData.append("upload_preset", "bigdeal_upload");

                let upload = await fetch(
                    "https://api.cloudinary.com/v1_1/oihf1seg/image/upload",
                    { method: "POST", body: formData }
                );
                let hasil = await upload.json();
                if (hasil.secure_url) {
                    urlFoto.push(hasil.secure_url);
                }
            }
        }

        let dataProduk = {
            nama: nama,
            kategori: kategori,
            subKategori: subKategori || "",
            badge: badge || "",
            kondisi: kondisi || "-",
            battery: battery || "-",
            harga: Number(harga),
            hargaCoret: hargaCoret ? Number(hargaCoret) : 0,
            deskripsi: deskripsi || "-",
            foto: urlFoto,
            status: "READY",
            tanggal: new Date()
        };

        if (idEdit) {
            delete dataProduk.tanggal;
            delete dataProduk.status;
            await updateDoc(doc(db, "produk", idEdit), dataProduk);
            alert("✅ Produk berhasil diupdate!");
        } else {
            await addDoc(collection(db, "produk"), dataProduk);
            alert("✅ Produk berhasil ditambahkan!");
        }

        resetForm();
        tampilProdukAdmin();

    } catch (error) {
        alert("❌ Gagal: " + error.message);
        console.error(error);
    } finally {
        let tombol = document.getElementById("tombolSimpan");
        tombol.disabled = false;
        tombol.innerHTML = idEdit ? "🔄 Update Produk" : "💾 Simpan Produk";
        sedangProses = false;
    }
};

// ============ BATAL EDIT ============
window.batalEdit = function() {
    if (confirm("Batalkan edit?")) {
        resetForm();
    }
};

// ============ TAMPIL PRODUK ADMIN ============
async function tampilProdukAdmin() {
    let daftar = document.getElementById("daftarProduk");
    daftar.innerHTML = '<div class="loading">⏳ Memuat produk...</div>';

    try {
        let q = query(collection(db, "produk"), orderBy("tanggal", "desc"));
        let data = await getDocs(q);

        if (data.empty) {
            daftar.innerHTML = '<p style="text-align:center; color:#666;">📭 Belum ada produk</p>';
            return;
        }

        daftar.innerHTML = "";
        data.forEach((item) => {
            let p = item.data();
            let foto = (p.foto && p.foto.length > 0) ? p.foto[0] : "https://via.placeholder.com/80x80/1a1a1a/2563eb?text=No+Image";

            daftar.innerHTML += `
                <div class="card">
                    <img src="${foto}" alt="${p.nama}">
                    <div class="info">
                        <h3>${p.nama || "-"}</h3>
                        <p>${p.kategori || "-"} ${p.subKategori ? '• ' + p.subKategori : ''} • ${p.kondisi || "-"}</p>
                        <p class="harga">Rp ${Number(p.harga || 0).toLocaleString("id-ID")}</p>
                        ${p.badge ? `<span style="background:#2563eb; padding:2px 10px; border-radius:30px; font-size:11px;">${p.badge}</span>` : ''}
                    </div>
                    <div class="actions">
                        <button class="edit" onclick="editProduk('${item.id}')">✏️ Edit</button>
                        <button class="delete" onclick="hapusProduk('${item.id}')">🗑️ Hapus</button>
                        <button class="status" onclick="ubahStatus('${item.id}','${p.status}')">${p.status === "READY" ? "📌 Ready" : "🔴 Sold"}</button>
                    </div>
                </div>
            `;
        });
    } catch (error) {
        daftar.innerHTML = `<p style="color:red;">❌ Error: ${error.message}</p>`;
    }
}

// ============ HAPUS ============
window.hapusProduk = async function(id) {
    if (!confirm("⚠️ Yakin hapus produk ini?")) return;
    try {
        await deleteDoc(doc(db, "produk", id));
        alert("✅ Produk dihapus");
        tampilProdukAdmin();
    } catch (error) {
        alert("❌ Gagal: " + error.message);
    }
};

// ============ UBAH STATUS ============
window.ubahStatus = async function(id, status) {
    let baru = status === "READY" ? "SOLD" : "READY";
    try {
        await updateDoc(doc(db, "produk", id), { status: baru });
        tampilProdukAdmin();
    } catch (error) {
        alert("❌ Gagal: " + error.message);
    }
};

// ============ EDIT PRODUK ============
window.editProduk = async function(id) {
    try {
        let q = query(collection(db, "produk"));
        let data = await getDocs(q);
        let ditemukan = false;

        data.forEach((item) => {
            if (item.id === id) {
                let p = item.data();
                document.getElementById("namaProduk").value = p.nama || "";
                document.getElementById("kategoriProduk").value = p.kategori || "Smartphone";
                document.getElementById("badgeProduk").value = p.badge || "";
                document.getElementById("kondisiProduk").value = p.kondisi || "";
                document.getElementById("batteryProduk").value = p.battery || "";
                document.getElementById("hargaProduk").value = p.harga || "";
                document.getElementById("hargaCoretProduk").value = p.hargaCoret || "";
                document.getElementById("subKategoriProduk").value = p.subKategori || "";
                document.getElementById("deskripsiProduk").value = p.deskripsi || "";
                idEdit = id;
                ditemukan = true;
            }
        });

        if (ditemukan) {
            document.getElementById("formTitle").innerHTML = "✏️ Edit Produk";
            document.getElementById("tombolSimpan").innerHTML = "🔄 Update Produk";
            document.getElementById("tombolBatal").style.display = "inline-block";
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    } catch (error) {
        alert("❌ Gagal: " + error.message);
    }
};

// ============ RESET FORM ============
function resetForm() {
    document.getElementById("namaProduk").value = "";
    document.getElementById("kategoriProduk").value = "Smartphone";
    document.getElementById("badgeProduk").value = "";
    document.getElementById("kondisiProduk").value = "";
    document.getElementById("batteryProduk").value = "";
    document.getElementById("hargaProduk").value = "";
    document.getElementById("hargaCoretProduk").value = "";
    document.getElementById("subKategoriProduk").value = "";
    document.getElementById("deskripsiProduk").value = "";
    document.querySelectorAll(".fotoProduk").forEach(input => input.value = "");
    idEdit = null;
    document.getElementById("formTitle").innerHTML = "➕ Tambah Produk Baru";
    document.getElementById("tombolSimpan").innerHTML = "💾 Simpan Produk";
    document.getElementById("tombolBatal").style.display = "none";
}