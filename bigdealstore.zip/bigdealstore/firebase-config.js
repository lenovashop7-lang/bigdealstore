import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-storage.js";

// ===== KONFIGURASI FIREBASE BIGDEALSTORE =====
const firebaseConfig = {
    apiKey: "AIzaSyAGzEez3hIyedjlFsx5VHXrGRw3-lko7Mc",
    authDomain: "bigdeal-4a544.firebaseapp.com",
    projectId: "bigdeal-4a544",
    storageBucket: "bigdeal-4a544.firebasestorage.app",
    messagingSenderId: "922281827785",
    appId: "1:922281827785:web:b4221e17c1fb27ac21dc18"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

export { db, storage };